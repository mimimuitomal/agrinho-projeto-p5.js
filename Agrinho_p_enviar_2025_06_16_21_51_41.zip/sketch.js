let player;
let trashes = [];
let score = 0;

function setup() {
  createCanvas(400, 400);
  player = new Player();

  for (let i = 0; i < 6; i++) {
    trashes.push(new Trash());
  }
}

function draw() {
  background(220);

  // Player
  player.update();
  player.show();

  // Trash
  for (let i = trashes.length - 1; i >= 0; i--) {
    trashes[i].move();
    trashes[i].show();

    if (player.collectTrash(trashes[i])) {
      if (trashes[i].recyclable) {
        score++;
      } else {
        score = max(0, score - 1);
      }
      trashes.splice(i, 1);
      trashes.push(new Trash());
    }
  }

  // Score display
  fill(0);
  textSize(16);
  text('Pontuação: ' + score, 10, 30);
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 40;
    this.size = 30;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;

    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);
  }

  show() {
    fill(0, 150, 255);
    rect(this.x, this.y, this.size, this.size);
  }

  collectTrash(trash) {
    let d = dist(this.x, this.y, trash.x, trash.y);
    return d < this.size / 2 + trash.size / 2;
  }
}

class Trash {
  constructor() {
    this.x = random(width);
    this.y = random(height - 50);
    this.size = 25;
    this.recyclable = random([true, false]); // Define o tipo do lixo aleatoriamente
    this.color = this.recyclable ? color(0, 255, 0) : color(255, 0, 0); // Verde = reciclável, vermelho = não reciclável
  }

  move() {
    // Lixo pode cair lentamente (opcional)
    this.y += 1.5;
    if (this.y > height) {
      this.y = 0;
      this.x = random(width);
    }
  }

  show() {
  textSize(this.size);
  textAlign(CENTER, CENTER);
  
  let emoji = this.recyclable ? '♻️' : '🚯';
  text(emoji, this.x, this.y);
    }
  }


